$(document).ready(function(){
  let numberOfAdults = 1;
  let checkIN;
  let checkOUT;
  let numberOfDays;
  let cost;
  
  function numOfDays() {
    if (checkIN && checkOUT) {
      console.log("Days")
      numberOfDays = checkOUT.diff(checkIN, "days")
      $('#daysDisplay').val(numberOfDays + " days");
    }
  }
  
  function calculateCost() {
    if (numberOfAdults && checkIN && checkOUT) {
      cost = 150 * numberOfAdults * numberOfDays;
      $('#costDisplay').val(cost);
    }
  }
  
  $('#checkIN').change(function() {
    checkIN = moment($(this).val());
    numOfDays();
    calculateCost();
  })
  
  $('#checkOUT').change(function() {
    checkOUT = moment($(this).val());
    numOfDays();
    calculateCost();
  })
  
  $('#adults').change(function() {
    numberOfAdults = $("#adults option:selected").val();
    calculateCost();
  })
  
  $('#reset').click(function() {
    toastr["info"]("Cleared", "", {
      "closeButton": true,
      "positionClass": "toast-top-full-width",
    });
    numberOfAdults = 1;
    checkIN = null;
    checkOUT = null;
    numberOfDays = null;
    $('#daysDisplay').html("Displays days...");
    $('#costDisplay').html("Displays cost...");
    validator.resetForm(true);
  })
  
  const validator = $('#form').validate({
    rules:{
      displayCost:{
        min:1
      }
    },
    messages:{
      username:"",
      firstName:"",
      lastName:"",
      inputPhone:"",
      inputFax:"",
      inputEmail:"",
      displayCost:"",
    },
    highlight: function (element, errorClass) {
      const name = $(element).attr("name")
      let errorMessage = "Missing field " + name;
      if(name === "costDisplay") {
        errorMessage = "Cost not calculated"
        if(cost <= 0) {
          errorMessage = "Cost must be more than equal to 0"
        }
      }
      toastr["error"](errorMessage, "", {
        "closeButton": true,
        "positionClass": "toast-top-right",
      });
      $(element).closest('.form-group').addClass("has-error");
    },
    unhighlight: function(element, errorClass) {
      $(element).closest('.form-group').removeClass('has-error');
    },
    submitHandler: function(form) {
      toastr["success"]("Submitted!", "", {
        "closeButton": true,
        "positionClass": "toast-top-full-width",
      });
      form.submit;
    },
  })
})